import argparse
import pandas as pd

def generate_report(csv_file, month, verbose=False):
    # Read the CSV file into a DataFrame
    df = pd.read_csv(csv_file)

    # Convert 'Birthday' column to datetime type
    df['Birthday'] = pd.to_datetime(df['Birthday'])
   

    # Filter data for the specified month
    month_data = df[df['Birthday'].dt.strftime('%B').str.lower() == month.lower()]
    month_data['Hiring Date'] = pd.to_datetime(month_data['Hiring Date'], format='%Y-%m-%d')


    # Count birthdays and anniversaries by department
    birthdays_by_dept = month_data[month_data['Birthday'].dt.day > 0].groupby('Department').size()
    anniversaries_by_dept = month_data[month_data['Hiring Date'].dt.day > 0].groupby('Department').size()

    # Print report
    print(f"Report for {month.capitalize()} generated")
    print("--- Birthdays ---")
    print(f"Total: {month_data[month_data['Birthday'].dt.day > 0].shape[0]}")
    print("By department:")
    for dept, count in birthdays_by_dept.items():
        print(f"- {dept}: {count}")
    print("--- Anniversaries ---")
    print(f"Total: {month_data[month_data['Hiring Date'].dt.day > 0].shape[0]}")
    print("By department:")
    for dept, count in anniversaries_by_dept.items():
        print(f"- {dept}: {count}")

    # Verbose mode: Print employee names
    if verbose:
        print("--- Employee Names ---")
        for _, row in month_data.iterrows():
            print(f"{row['Name']}: {row['Department']}")

if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Generate monthly report")
    parser.add_argument("csv_file", type=str, help="Path to CSV file")
    parser.add_argument("month", type=str, help="Month (e.g., January, February, etc.)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Print employee names")
    args = parser.parse_args()

    # Generate report
    generate_report(args.csv_file, args.month, args.verbose)
